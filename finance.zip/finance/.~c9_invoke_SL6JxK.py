import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    #SYMBOL     NAME        SHARES      PRICE       TOTALVALUE
    #AAPL       Apple       6           215.40      1250.23
    #CASH                                           8800.00
    #                                               10050.23

    currentuserlistdict = db.execute("SELECT username FROM users WHERE id=:userid", userid=session['user_id'])
    currentuserstr = currentuserlistdict[0]['username']

    cashlistdict = db.execute("SELECT cash FROM users WHERE username=:username", username=currentuserstr)
    cashnum = cashlistdict[0]['cash']


    rows = db.execute("SELECT * FROM holdings WHERE username=:username", username=currentuserstr)

    portfoliovalue = 0
    #NOW CREATE TABLE
    #loop through list of dictionarys and add price and value of holdings to each dictionary
    for row in rows:
        symbol = row['symbol']

        pricedict = lookup(symbol)
        price = pricedict['price']

        namedict = lookup(symbol)
        name = namedict['name']

        shares = row['shares']
        holdingsvalue = price * shares
        portfoliovalue = portfoliovalue + holdingsvalue
        row.update( {'price':price} )
        row.update( {'value':holdingsvalue} )
        row.update( {'name':name} )


    cashlistdict = db.execute("SELECT cash FROM users WHERE username=:username", username=currentuserstr)
    cashnum = cashlistdict[0]['cash']
    portfoliovalue = portfoliovalue + cashnum

    print("DATA MANIPULATION SUCCESSFUL, RENDER PENDING")
    return render_template("index.html", holdinglistdict=rows, cash=cashnum, total=portfoliovalue)
    #add cash holdings dictionary object to list of dictionarys
    #add dictionary object for total value of holdings to list of dictionarys
    #IN HTML loop through list of dictionarys and print into table


    #return apology("TODO HOLDINGS PAGE")


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":

        symbol = request.form.get("symbol")
        shares = float(request.form.get("shares"))
        price = lookup(symbol)['price']

        currentuserlistdict = db.execute("SELECT username FROM users WHERE id=:userid", userid=session['user_id'])
        currentuserstr = currentuserlistdict[0]['username']

        cashlistdict = db.execute("SELECT cash FROM users WHERE username=:username", username=currentuserstr)
        cashnum = cashlistdict[0]['cash']

        if not symbol:
            return apology("enter stock symbol", 403)
        elif lookup(symbol) == None:
            return apology("enter valid symbol", 403)
        elif not shares:
            return apology("enter number of shares", 403)
        elif shares == 0:
            return apology("must buy at least 1 share", 403)
        elif ((price * shares) > cashnum):
            return apology("not enough money", 403)

        else:
            testvar = 1
            rows = db.execute("SELECT * FROM holdings WHERE username=:username AND symbol=:symbol",
                symbol=symbol, username=currentuserstr)

            if len(rows) == 0: #if none of this stock is owned by user/no row exists (have not previously owned and sold it all)
                db.execute("INSERT INTO holdings (username,symbol,shares) VALUES (:username,:symbol,:shares)",
                    username=currentuserstr, symbol=symbol, shares=shares)

                cashspent = price * shares
                newtotalcash = cashnum - cashspent
                db.execute("UPDATE users SET cash=:cash WHERE username=:username",
                    cash=newtotalcash, username=currentuserstr)

            else: #user already owns shares of this stock or previously did (owns "0" in db)
                #db.execute(add number of shares purchased to current number of shares)
                ownedshares = rows[0]['shares']
                newtotalshares = shares + ownedshares
                db.execute("UPDATE holdings SET shares=:shares WHERE username=:username AND symbol=:symbol",
                    shares=newtotalshares, username=currentuserstr, symbol=symbol)#add to holdings

                cashspent = price * shares
                newtotalcash = cashnum - cashspent
                db.execute("UPDATE users SET cash=:cash WHERE username=:username",
                    cash=newtotalcash, username=currentuserstr)

                db.execute("INSERT INTO transactions (username,symbol,shares,price,timestamp) VALUES (:username,:symbol,:shares,:price,:timestamp)",
                    username=currentuserstr, symbol=symbol, shares=shares, price=price, timestamp=datetime.now())

            return redirect("/")


            #generate holdings database once
            #complete buy process
            #subtract cash from holdings
            #return to holdings page?

    else:
        return render_template("buy.html")

    return apology("TODO")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    #(USER)     Symbol      Shares      Price       Transacted
    #           AAPL        5           $XXX.XX     2020-04-20 14:53:20
    #           AAPL        -3          $XXX.XX     2020-04-21 08:51:14

    currentuserlistdict = db.execute("SELECT username FROM users WHERE id=:userid", userid=session['user_id'])
    currentuserstr = currentuserlistdict[0]['username']

    transactionlistdict = db.execute("SELECT * FROM transactions WHERE username=:username", username=currentuserstr)

    if len(transactionlistdict) == 0:
        return apology("you have no transactions to list", 403)

    else:
        return render_template("history.html", transactionlistdict=transactionlistdict)

    #ADD DBEXECUTE TO SALE PAGE
    #ADD DBEXECUTE TO BUY PAGE
    #CREATE METHOD FOR REQUESTING INFORMATION FROM TABLE
    #CREATE METHOD FOR DISPLAYING THAT INFO
    return apology("TODO")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/") #CHANGE TO /

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"]) #DO THIS RIGHT NOW
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        symbol = request.form.get("symbol")

        #if ticker form is empty
        if not symbol:
            return apology("must enter a symbol", 403)

        #if ticker does not exist
        elif lookup(symbol) == None:
            return apology("symbol does not exist", 403)

        #if ticker exists, print quote
        else:
            quotedict = lookup(symbol)
            dollars = '{:.2f}'.format(quotedict['price'])
            return render_template("quoted.html", quotedict=quotedict, dollars=dollars)


    else:
        #USER REQUESTS A QUOTE FROM QUOTE PAGE
        return render_template("quote.html")
    return apology("TODO")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        #REGISTER USER

        # Ensure username isn't already in database
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username was filled in
        if not request.form.get("username"):
            return apology("must provide username", 403)

        elif len(rows) == 1:
            return apology("username already taken", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        #Ensure passwords match
        elif request.form.get("password") != request.form.get("confirmpassword"):
            return apology("passwords must match", 403)

        else:
            #FIGURE OUT HOW TO HASH PASSWORD
            password = request.form.get("password")
            username = request.form.get("username")
            passwordhash = generate_password_hash(password)
            db.execute("INSERT INTO users (username, hash) VALUES (:username, :passwordhash)", username=username, passwordhash=passwordhash)

            # Redirect user to login form
            return redirect("/")

            #ADD TO DB
            #RETURN TO LOGIN SCREEN

    else:
        return render_template("register.html")

    return apology("TODO")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    currentuserlistdict = db.execute("SELECT username FROM users WHERE id=:userid", userid=session['user_id'])
    currentuserstr = currentuserlistdict[0]['username']
    holdingslistdict = db.execute("SELECT symbol,shares FROM holdings WHERE username=:user", user=currentuserstr)
    #TURN STOCK SELECTION HTML INTO DROPDOWN OF OWNED STOCK, IN GET METHOD

    cashlistdict = db.execute("SELECT cash FROM users WHERE username=:username", username=currentuserstr)
    cashnum = cashlistdict[0]['cash']


    #if submitting sale order
    if request.method == "POST":
        testvar = 1
        #HANDLE LOGIC OF SALE HERE
        symbol = request.form.get("symbol")
        shares = float(request.form.get("shares"))
        price = lookup(symbol)['price']
        ownedshareslistdict = db.execute("SELECT shares FROM holdings WHERE username=:user AND symbol=:symbol", user=currentuserstr, symbol=symbol)

        if not symbol:#symbol field is empty
            testvar = 1
            return apology("must specify stock", 403)

        elif shares <= 0:#not selling > 0 shares
            testvar = 1
            return apology("must sell some shares", 403)

        elif len(ownedshareslistdict) < 1:#specifies stock they do not own #CAN ELIMINATE ONCE DROPDOWN IS CREATED
            testvar = 1
            return apology("you don't own that stock", 403)

        elif ownedshareslistdict[0]['shares'] < shares:#does not own that many shares
            testvar = 1
            return apology("you don't own that many shares", 403)

        else: #SUCCESSFUL SALE
            testvar = 1
            #UPDATE number of owned shares with dbexecute
            newtotalshares = ownedshareslistdict[0]['shares'] - shares
            db.execute("UPDATE holdings SET shares=:shares WHERE username=:username AND symbol=:symbol",
                shares=newtotalshares, username=currentuserstr, symbol=symbol)

            #create variable for value of sale and update cash holdings variable
            newcash = cashnum + (price * shares)
            #UPDATE cash holdings with dbexecute
            db.execute("UPDATE users SET cash=:cash WHERE username=:username", cash=newcash, username=currentuserstr)

            db.execute("INSERT INTO transactions (username,symbol,shares,price,timestamp) VALUES (:username,:symbol,:shares,:price,:timestamp)",
                username=currentuserstr, symbol=symbol, shares=(shares * -1), price=price, timestamp=datetime.now())

        return redirect("/")

    #if requesting page from a link, etc
    else:
        testvar = 1
        return render_template("sell.html")

    return apology("TODO")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
